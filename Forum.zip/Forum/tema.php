<?php
session_start();
require("db_connect.php");
$aktualni_id =(int) $_GET['id'];
if ($_POST)
{
    if (empty($_POST['komentar_text']))
    {

    } else {
$sql2='INSERT INTO komentar (komentar_login, komentar_tema_id, komentar_text) VALUES (?,?,?);';

$pdo->prepare($sql2)->execute([$_SESSION["Username"], $aktualni_id, $_POST['komentar_text']]);
   
    }
}
?>
<html>
    <head>
      <!--  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
     -->
      <meta http-equiv="content-type" content="text/html; charset=utf-8">
        <meta name="generator" content="PSPad editor, www.pspad.com">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="main.css">
        <style>
            
        </style>	
        <title>Navrh na menu</title>
    </head>
    
    <body>                                     
        <nav class="navbar navbar-expand-md sticky-top">
            
            <a class="navbar-brand" href="#"><img src="logo.png" width="80" height="50"/></a>
            <a class="navbar-brand" href="#"><b>logo</b></a>
            <a class="navbar-brand" href="#"><b>logo</b></a>
            <a class="navbar-brand" href="#"><b>logo</b></a>
            <a class="navbar-brand" href="#"><b>logo</b></a>
            <a class="navbar-brand" href="#"><b>logo</b></a>
            
            
            
            <!-- 
            
            
                 Toto je vyjížděcí menu!!!!
                 
            
            <div class="dropdown">                                          
             <a class="dropbtn" href="#"><b>Menu</b></a>
             <div class="dropdown-content">
               <a  href="#">Kontakt</a>
               <a  href="#">Rezervace</a>
               <a  href="#">Články</a>
               <a  href="#">Forum</a>
             </div>
           </div>  
            -->
            
            
            <button class="navbar-toggler navbar-dark " type="button" data-toggle="collapse" data-target="#main-navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            
            <div class="collapse navbar-collapse" id="main-navigation">
                
                <ul class="navbar-nav">
                    
                    
                    
                    
                    
                    <li class="nav-item">
                        <a class="nav-link" href="#od3"><b>Přihlášení</b></a>
                    <li class="nav-item">
                        <form class="form-inline my-2 my-lg-0">
                            <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
                            <button class="btn btn-light" type="submit">Search</button>
                        </form>
                    </li>
                </ul>
            </div>
        </nav><br><br><br>
    <center>
        
        
        &nbsp;<br>
        &nbsp;<br>
        &nbsp;<br>
        <center>
            
            <div class='forum'>
                
                <br>
                
                <table >
                    
                    
                          <?php

$sql = "SELECT tema_vznik, tema_nadpis, tema_text, tema_login, icon from tema join login_redaktor on tema_login=login_redaktor.login where tema.tema_id = '". $aktualni_id ."';";
$vysledek = $pdo->query($sql);
if (($radek = $vysledek->fetch(PDO::FETCH_BOTH)) != FALSE) {
    echo("<tr class='barvatabulky bila'><td  colspan='2'>$radek[tema_nadpis]</td></tr>");
     echo("<tr><td><p class='stred'>$radek[tema_login]<br />");
     switch ($radek[icon]) {
         case 1:
echo'<img src="dogo.png" />';
             break;
         case 2:
echo'<img src="roh.png" />';
             break;
      case 3:
echo'<img src="lebkov.png" />';
             break;
     }
     
     echo("</p></td><td class='tablesirka'><p class='stred'>$radek[tema_text]</p> <p class=\"odpovedet\"> $radek[tema_vznik]&nbsp;&nbsp;&nbsp;</p></td></tr>");
     

echo '<tr class="barvatabulky bila" >  <td  class="bila"  colspan="2">Odpovědi</td></tr> ';

$sql = "SELECT datum, komentar_text, komentar_login, icon FROM komentar JOIN login_redaktor ON komentar_login=login_redaktor.login JOIN tema ON komentar.komentar_tema_id=tema.tema_id where tema.tema_id = '".$aktualni_id."' order by datum;";
$vysledek2 = $pdo->query($sql);
while (($radek2 = $vysledek2->fetch(PDO::FETCH_BOTH)) != FALSE):
echo("<tr><td><p class='stred'>$radek2[komentar_login]<br />");
     switch ($radek2[icon]) {
         case 1:
echo'<img src="dogo.png" />';
             break;
         case 2:
echo'<img src="roh.png" />';
             break;
      case 3:
echo'<img src="lebkov.png" />';
             break;
     }
        echo("</p> </td><td class='tablesirka'><p class='stred'>$radek2[komentar_text]</p> <p class='odpovedet'> $radek2[datum]&nbsp;&nbsp;&nbsp;</p></td></tr>");
endwhile;
} else {
    echo "Toto téma neexistuje";
}
?>
                </table>
            
            <?php
               echo ("<form method=\"post\" action=\"tema.php?id=$aktualni_id\">");
               echo $_SESSION["Username"];
               ?>
                
                <div class="form"> 

    <textarea style="resize: auto; width:95%; margin-top: 10px; min-width: 350px; min-height:200px;" placeholder="Komentář" class="obsah" id="exampleFormControlTextarea1" name="komentar_text"></textarea><hr> 
    <button type="submit" class="btn btn-secondary btn-lg active" value="Uložit"> Přidat komentář </button>
  </div><br /> </form>
            </div>
            
            
            <footer class="page-footer">
                
                <div class="container">
                    <div class="row">
                        
                        <div class="footer_second">
                            <h6>Nadpis</h6>
                            <p>text</p>
                        </div>
                        
                        <div class="footer_second">
                            <h6>Nadpis</h6>
                            <p>text</p>
                        </div>
                        
                        <div class="footer_second">
                            <h6>Nadpis</h6>
                            <p>text</p>
                        </div>
                        
                        <div class="footer_second">
                            <h6>Nadpis</h6>
                            <p>text</p>
                        </div>
                        
                    </div>
                </div>
                <div class="footer_lupinci">2020/2021 : tým Lupínci</div>
                <div class="footer_odkaz">Odkaz na  <a><b>VSPJ</b></a></div>
                
                
                
                
            </footer>
            
            
            
            </body>
            </html>
            
            <!-- 
            <div class="container">
            <div class="row">
            <div class="col-lg-8 col-md-8 col-sm-12">
            <h6 class="text-uppercase font-weight-bold">Informace</h6>
             <p>Text</p>
           </div>
             <div class="footer_second">
            <h6 class="text-uppercase font-weight-bold">Fotky</h6>
             <p>Text</p>
           </div>
               <div class="col-lg-4 col-md-4 col-sm-12">
                 <h6 class="text-uppercase font-weight-bold">Kontakt</h6>
                 <p>Jihlava
                 <br>Studenti
                 <br><a href="" class="">YouTube</a>
                           </p>
               </div>
             </div>
           </div>
            
            -->
