<?php
$servername = "localhost";
$username = "lupinci";
$password = "Lup1nc12020*";
$dbname = "lupinci";
$spojeni = mysqli_connect($servername, $username, $password, $dbname);
 mysqli_set_charset($spojeni, "utf8");
?>
