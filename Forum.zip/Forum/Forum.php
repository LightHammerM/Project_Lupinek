<?php
require("connect.php");
?>
<html>
    <head>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <meta http-equiv="content-type" content="text/html; charset=utf-8">
        <meta name="generator" content="PSPad editor, www.pspad.com">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="main.css">
        
        <title>Navrh na menu</title>
    </head>
    
    <body>     
        


        
        
        <nav class="navbar navbar-expand-md sticky-top">
            
            <a class="navbar-brand" href="#"><img src="logo.png" width="80" height="50"/></a>
            <a class="navbar-brand" href="#"><b>logo</b></a>
            <a class="navbar-brand" href="#"><b>logo</b></a>
            <a class="navbar-brand" href="#"><b>logo</b></a>
            <a class="navbar-brand" href="#"><b>logo</b></a>
            <a class="navbar-brand" href="#"><b>logo</b></a>
            
            
            
            <!-- 
            
            
                 Toto je vyjížděcí menu!!!!
                 
            
            <div class="dropdown">                                          
             <a class="dropbtn" href="#"><b>Menu</b></a>
             <div class="dropdown-content">
               <a  href="#">Kontakt</a>
               <a  href="#">Rezervace</a>
               <a  href="#">Články</a>
               <a  href="#">Forum</a>
             </div>
           </div>  
            -->
            
            
            <button class="navbar-toggler navbar-dark " type="button" data-toggle="collapse" data-target="#main-navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            
            <div class="collapse navbar-collapse" id="main-navigation">
                
                <ul class="navbar-nav">
                    
                    
                    
                    
                    
                    <li class="nav-item">
                        <a class="nav-link" href="#od3"><b>Přihlášení</b></a>
                    <li class="nav-item">
                        <form class="form-inline my-2 my-lg-0">
                            <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
                            <button class="btn btn-light" type="submit">Search</button>
                        </form>
                    </li>
                </ul>
            </div>
        </nav><br><br><br>
    <center>
        
        
        <div class='forum'>
            <button class='btn-danger left' type="button"><a class="barva12" href="forum1.php">přidat nové téma</a></button>
            <br>
            
            <table class='tablesirka'>
                
                <tr class="barvatabulky bila" ><td>Téma</td><td>Autor</td></tr>
                        <?php
                        
$sql = "SELECT tema_nadpis, tema_login, tema_id from tema order by tema_vznik;";
$vysledek = $spojeni->query($sql);


 while ($radek = mysqli_fetch_assoc($vysledek)):
     echo ("<tr><td><p><a href=\"tema.php?id=$radek[tema_id]\">$radek[tema_nadpis]</a></p></td><td>$radek[tema_login]</td></tr>");

endwhile;



?>
  
        
            </table>
        </div>
        
        
    </center>
    
    
    
    
    <footer class="page-footer">
        
        <div class="container">
            <div class="row">
                
                <div class="footer_second">
                    <h6>Nadpis</h6>
                    <p>text</p>
                </div>
                
                <div class="footer_second">
                    <h6>Nadpis</h6>
                    <p>text</p>
                </div>
                
                <div class="footer_second">
                    <h6>Nadpis</h6>
                    <p>text</p>
                </div>
                
                <div class="footer_second">
                    <h6>Nadpis</h6>
                    <p>text</p>
                </div>
                
            </div>
        </div>
        <div class="footer_lupinci">2020/2021 : tým Lupínci</div>
        <div class="footer_odkaz">Odkaz na  <a><b>VSPJ</b></a></div>
        
        
        
        
    </footer>
    
    
    
</body>
</html>

<!-- 
<div class="container">
<div class="row">
<div class="col-lg-8 col-md-8 col-sm-12">
<h6 class="text-uppercase font-weight-bold">Informace</h6>
 <p>Text</p>
</div>
 <div class="footer_second">
<h6 class="text-uppercase font-weight-bold">Fotky</h6>
 <p>Text</p>
</div>
   <div class="col-lg-4 col-md-4 col-sm-12">
     <h6 class="text-uppercase font-weight-bold">Kontakt</h6>
     <p>Jihlava
     <br>Studenti
     <br><a href="" class="">YouTube</a>
               </p>
   </div>
 </div>
</div>

-->
