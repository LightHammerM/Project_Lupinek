<?php
// Start the session
session_start();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<meta name="generator" content="PSPad editor, www.pspad.com">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="styles/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="styles/css/main.css">
<style>
#pokus{
  text-align:left:50%;
}
 .datum_style{
 text-align:right;
 color:red;
 }
  h4{
text-align:left;
padding-left:1%;
}
</style>
<title>Navrh na menu</title>
</head>

<body>

<nav class="navbar navbar-expand-md sticky-top">

<a class="navbar-brand" href="Index.php"><img src="logo.PNG" width="80" height="50"/></a>
<a class="navbar-brand" href="#"><b>logo</b></a>
<a class="navbar-brand" href="#"><b>logo</b></a>
<a class="navbar-brand" href="#"><b>logo</b></a>
<a class="navbar-brand" href="#"><b>logo</b></a>

<?php
 if($_SESSION["Opravneni"] >= 5){
 
 echo('
<a class="navbar-brand" href="novinky11.php"><b>Přidat Novinky</b></a> 
');
 }
?>




<!--


Toto je vyjížděcí menu!!!!


<div class="dropdown">
<a class="dropbtn" href="#"><b>Menu</b></a>
<div class="dropdown-content">
<a  href="#">Kontakt</a>
<a  href="#">Rezervace</a>
<a  href="#">Články</a>
<a  href="#">Forum</a>
</div>
</div>

-->


<button class="navbar-toggler navbar-dark " type="button" data-toggle="collapse" data-target="#main-navigation">
<span class="navbar-toggler-icon"></span>
</button>

<div class="collapse navbar-collapse" id="main-navigation">

<ul class="navbar-nav">

<?php


echo('<li class="nav-item"><a class="nav-link" href=""><b>'.$_SESSION["Username"].'</b></a>');

 switch ($_SESSION["Icon"]) {
 	case 1: echo('<li class="nav-item"><img src="dogo.png" height="50px">');break;
    case 2: echo('<li class="nav-item"><img src="roh.png" height="50px">');break;
    case 3: echo('<li class="nav-item"><img src="lebkov.png" height="50px">');break;
 } 
 

?>
 

<li class="nav-item">
 <?php
 if($_SESSION["user_is_logged"]==1){
echo('<li class="nav-item"><a class="nav-link" href="logout.php"><b>Odhlásit se</b></a>'); 
 echo('<li class="nav-item">
<form class="form-inline my-2 my-lg-0">
<input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
<button class="btn btn-light" type="submit">Search</button>
</form>  
');
 }
 else
 echo('<a class="nav-link" href="registration.php"><b>Registrace</b></a>
<li class="nav-item">
<li class="nav-item">
<a class="nav-link" href="login.php"><b>Přihlášení</b></a>
<li class="nav-item">
<form class="form-inline my-2 my-lg-0">
<input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
<button class="btn btn-light" type="submit">Search</button>
</form>') ; 
?>
</li>
</ul>
</div>
</nav><br><br><br>


<center>
<div class="novinky_full">
  <form name="myLetters" action="pokus.php" method="POST">
<?php
$servername = "localhost";
$username = "lupinci";
$password = "Lup1nc12020*";
$dbname = "lupinci";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM novinky";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
echo " <center> <div class='novinky_vypis'>";
echo "<h4>".$row["titulek"]. "</h4><br> " . $row["obsah"]. " <br><i class='datum_style'>" . $row["datum"]. "</i>"; 
echo '<br><button type="submit" id="pokus" class="btn btn-outline-danger" name="btn" value="' . $row['novinky_id'] . '">Upravit</button>';
echo " </center> </div>";
}
} else {
echo "0 results";
}
$conn->close();
?>
    </form>
</div>
</center>



<br><br><br>





<footer class="page-footer">

<div class="container">
<div class="row">

<div class="footer_second">
<h6>Developeři</h6>
<p>Produck Owner: korbel05(Jenýk Korbel)</p>
<p>Scrum master: blazej04(Michal Blažejovský)</p>
<p>Member: straka07(Jan Straka)</p>
<p>Member: prihod12(Tadeáš Příhoda)</p>
<p>Member: kovali01(Jan Kovalík)</p>
<p>Member: servit01(Petr Servít)</p>
</div>

<div class="footer_second">
<h6>Nadpis</h6>
<p>text</p>
</div>

<div class="footer_second">
<h6>Nadpis</h6>
<p>text</p>
</div>

<div class="footer_second">
<h6>Nadpis</h6>
<p>text</p>
</div>

</div>
</div>
<div class="footer_lupinci">2020/2021 : tým Lupínci</div>
<div class="footer_odkaz">Odkaz na  <a><b>VSPJ</b></a></div>




</footer>



</body>
</html>

<!--
<div class="container">
<div class="row">
<div class="col-lg-8 col-md-8 col-sm-12">
<h6 class="text-uppercase font-weight-bold">Informace</h6>
<p>Text</p>
</div>

<div class="footer_second">
<h6 class="text-uppercase font-weight-bold">Fotky</h6>
<p>Text</p>
</div>

<div class="col-lg-4 col-md-4 col-sm-12">
<h6 class="text-uppercase font-weight-bold">Kontakt</h6>
<p>Jihlava
<br>Studenti
<br><a href="" class="">YouTube</a>
</p>
</div>

</div>
</div>

-->
