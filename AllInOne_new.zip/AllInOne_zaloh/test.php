<?php
$hash
Locale::setDefault('en-US'); = '$2y$07$BCryptRequires22Chrcte/VlQH0piJtjXl.0t1XkA8pw9dMXTpOq';
$inputPassword = 'rasmuslerdorf';

echo password_verify($inputPassword, $hash) ? 'Heslo ov��eno' : '�patn� heslo'.    ?>