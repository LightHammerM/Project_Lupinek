<?php
 require("connect.php");
 $salt="salt"; 
 
 $protected="Index.php";
 $css="styles.css";

 $sql = "select heslo,ID_Opr,icon from login_redaktor Where login='".$_POST['user']."'";
 $vysledek = mysqli_query($spojeni, $sql);
 $radek = mysqli_fetch_assoc($vysledek);
 $my_string = $radek['ID_Opr'];
 $my_string2 = $radek['icon'];
 
 
 if ($_GET['action']=='validate'){
   if((hash_hmac('sha256', $_POST['passwd'],$salt)==$radek['heslo'])){
     session_start();
     header("Cache-control: private");
     $_SESSION["user_is_logged"] = 1;
     $_SESSION["Opravneni"] = $my_string;
     $_SESSION["Icon"] = $my_string2;
     $_SESSION["Username"] = $_POST['user'];
     header("Location:".$protected);
     exit;
   }
 }       
?>

<style>
.form
{

position: relative;
background-image: url(form.png);
background-repeat: no-repeat;
background-position: center;
height: 80%;
text-align: center;

}
</style>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN"
 "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd"> 
 <HTML>                           
 <HEAD>
 <meta http-equiv="content-type" content="text/html; charset=iso-8859-2"/>
 <link href="bootstrap/css/bootstrap.css" media="all" type="text/css" rel="stylesheet">
  <link href="styly.css" media="all" type="text/css" rel="stylesheet">
 </HEAD>
 <BODY>
 <div class="hlava"  ><p style="font-size: 64px">Logos Polytechnos</p></div>
<form action="./login.php?action=validate" method="post">
<div class="form"> 
<br><br><br><br><br><br><br><br><br><br><br><br>
    <h5>Login:&nbsp;&nbsp;<input type="text" name="user" /></h5> <br>
    <h5>Heslo:&nbsp;&nbsp;<input type="password" name="passwd" /></h5> <br><br><br><br><br><br>
    <button type="submit" class="btn btn-outline-light" value="Login" /> Přihlášení </button>
 </div></form>
 </BODY>
 
 
                                                                                                               <br>




 
 
 <div class="pata" >Kok</div>
 </HTML>






