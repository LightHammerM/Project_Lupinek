<?php
 require("connect.php");
?>
<?php
$pass = hash_hmac('sha256', "$_GET[passwd]","salt");
?>
<?php
$sql = "INSERT INTO login_redaktor (login,heslo,email,icon)
values('$_GET[user]','$pass','$_GET[email]','$_GET[icon]')";
?>

<style>
.form
{

position: relative;
background-image: url(form.png);
background-repeat: no-repeat;
background-position: center;
height: 80%;
text-align: center;

}
</style>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN"
 "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd"> 
 <HTML>                           
 <HEAD>
 <meta http-equiv="content-type" content="text/html; charset=iso-8859-2"/>
 <link href="bootstrap/css/bootstrap.css" media="all" type="text/css" rel="stylesheet">
  <link href="styly.css" media="all" type="text/css" rel="stylesheet">
 </HEAD>
 <BODY>  
 <div class="hlava"  ><p style="font-size: 64px">Logos Polytechnos</p></div><div class="form">
<h3> <br><br><br><br><br><br><br><br><br><br><br>
<?php
  

 if (mysqli_query($spojeni, $sql)) {
    echo "Záznam byl úspešně přidán";
} else {
    echo "Bohužel, váš účet nebylo možné vytvořit";
} ?>
</h3>
<br><br><br>
<a href="Index.php"><button class="btn btn-outline-light"> Zpět na hlavní stránku </button></a>
 </div></BODY>
 

                                                                                                               <br>



 
 
 <div class="pata" >Kok</div>
 </HTML>







