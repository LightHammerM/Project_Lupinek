
<footer class="page-footer" style="display: block; position: absolute; bottom: 0;  background-color: #555555; width:100%;">

<div class="container">
<div class="row">

<div class="footer_second">
<h6>Developeři</h6>
<p>Produck Owner: korbel05(Jenýk Korbel)</p>
<p>Scrum master: blazej04(Michal Blažejovský)</p>
<p>Member: servit01(Petr Servít)</p>
</div>

<div class="footer_second">
<h6>Developeři</h6>
<p>Member: straka07(Jan Straka)</p>
<p>Member: prihod12(Tadeáš Příhoda)</p>
<p>Member: kovali01(Jan Kovalík)</p>
</div>

<div class="footer_second">
<h6></h6>
</div>

</div>
</div>
<div class="footer_lupinci">2020/2021 : tým Lupínci</div>
<div class="footer_odkaz">Odkaz na  <a><b>VSPJ</b></a></div>




</footer>
