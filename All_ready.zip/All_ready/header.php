<nav class="navbar navbar-expand-md sticky-top">

<a class="navbar-brand" href="Index.php"><img src="logo.PNG" width="80" height="50"/></a>
<a class="navbar-brand" href="Forum.php"><b>Fórum</b></a>

<?php
 if($_SESSION["user_is_logged"] == 1){ 
 echo('
<a class="navbar-brand" href="Kontakt.php"><b>Kontakt</b></a> 
<a class="navbar-brand" href="Redakce.php"><b>Rezervace</b></a> 
');
 }
 if($_SESSION["Opravneni"] >= 5){
 
 echo('
<a class="navbar-brand" href="novinky11.php"><b>Přidat Novinky</b></a> 
<a class="navbar-brand" href="historie.php"><b>Historie úprav</b></a> 
');
 }
 if($_SESSION["Opravneni"] >= 6){
 
 echo('
<a class="navbar-brand" href="admin.php"><b>Admin panel</b></a> 
');
 }
?>


<button class="navbar-toggler navbar-dark " type="button" data-toggle="collapse" data-target="#main-navigation">
<span class="navbar-toggler-icon"></span>
</button>

<div class="collapse navbar-collapse" id="main-navigation">

<ul class="navbar-nav">

<?php


echo('<li class="nav-item"><a class="nav-link" href=""><b>'.$_SESSION["Username"].'</b></a>');

 switch ($_SESSION["Icon"]) {
 	case 1: echo('<li class="nav-item"><img src="dogo.png" height="50px">');break;
    case 2: echo('<li class="nav-item"><img src="roh.png" height="50px">');break;
    case 3: echo('<li class="nav-item"><img src="lebkov.png" height="50px">');break;
 } 
 

?>
 

<li class="nav-item">
 <?php
 if($_SESSION["user_is_logged"]==1){
echo('<li class="nav-item"><a class="nav-link" href="logout.php"><b>Odhlásit se</b></a>'); 
 echo('<li class="nav-item">
<form class="form-inline my-2 my-lg-0">
<input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
<button class="btn btn-light" type="submit">Search</button>
</form>  
');
 }
 else
 echo('<a class="nav-link" href="registration.php"><b>Registrace</b></a>
<li class="nav-item">
<li class="nav-item">
<a class="nav-link" href="login.php"><b>Přihlášení</b></a>
<li class="nav-item">
<form class="form-inline my-2 my-lg-0">
<input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
<button class="btn btn-light" type="submit">Search</button>
</form>') ; 
?>
</li>
</ul>
</div>
</nav>