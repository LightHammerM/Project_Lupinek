<?php
session_start();

 require("connect.php");

$sql = "UPDATE Rezervace SET But_stat='1', Autor='$_GET[Name_clan]', Pracoviste='$_GET[Prac_clan]', Clanek='$_GET[Clan_clan]', Obsah='$_GET[Obsah_clan]', USER='$_SESSION[Username]' WHERE ID_But=$_SESSION[ID]";

if (mysqli_query($spojeni, $sql)) {
    echo "Z�znam byl �spe�n� p�id�n";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($spojeni);
}
mysqli_close($spojeni); 
header("Location: Redakce.php");exit;
    ?>