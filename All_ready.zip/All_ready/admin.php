<?php
require("db_connect.php");
session_start();
  ?>

<html>
  <head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <meta name="generator" content="PSPad editor, www.pspad.com">
  	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="main.css">
  
    <style>
   
    </style>	
  <title>Navrh na menu</title>
  </head>
  
  <body>                                     
<?php
 require 'header.php';
?><br><br><br>
     <center>

  
&nbsp;<br>
&nbsp;<br>
&nbsp;<br>


  
 <div class='forum'>
  
  <br>
 
 <table >
 
     <tr class="barvatabulky bila"   ><td><a class="navbar-brand" href="admin.php?tb=tema">Fórum</a></td>
 <td><a class="navbar-brand" href="admin.php?tb=komentar">Komentář</a></td>
 <td><a class="navbar-brand" href="admin.php?tb=novinky">Novinky</a></td>
 </tr>
 
 
 
 </table>
  <table>         
                          <?php
if($_GET[tb]==null){
           $_GET[tb]="tema";                 //přidal honza když aby byl vidět footer
                          }
                          
$sql = ("SELECT * FROM ".$_GET[tb]);

$vysledek = $pdo->query($sql);
//echo $sql;

$radek = $vysledek->fetch();
$col = array_keys($radek);
//print_r(array_keys($radek));
$i=0;
echo ("<tr>");
     while(!empty($col[$i])) {
         
         echo ("<td>$col[$i]</td>");
         $i+=2;
     }
     echo ("<td>Smazat</td>");
     if($_GET[tb]=="novinky") {
         echo"<td>Upravit</td>";
     }
            echo ("</tr>");
     
     
     
do {
    $i=0;
   echo ("<tr>");
     while(!empty($col[$i])) {
         $index=$col[$i];
         echo ("<td>$radek[$index]</td>");
         $i+=2;
     }

    
    
    switch ($_GET[tb]) {
        case "tema":
        echo ("<td><a href='admin_delete.php?idcol=tema_id&tb=$_GET[tb]&id=$radek[tema_id]'>Smazat</a></td></tr>");
    break;
        case "komentar":
                    echo ("<td><a href='admin_delete.php?idcol=komentar_id&tb=$_GET[tb]&id=$radek[komentar_id]'>Smazat</a></td></tr>");

            break;
        case "novinky":
                    echo ("<td><a href='admin_delete.php?idcol=novinky_id&tb=$_GET[tb]&id=$radek[komentar_id]'>Smazat</a></td><td><a href='admin_update.php?idcol=tema_id&tb=tema&id=$radek[tema_id]'>Upravit</a></td></tr>");

            break;
            
    }
} while (($radek = $vysledek->fetch(PDO::FETCH_BOTH)) != FALSE);
?>
  
  </table>
 </div>
 </center>

<footer class="page-footer" style="display: block; position: relative; bottom: 0;  background-color: #555555; width:100%;">

<div class="container">
<div class="row">

<div class="footer_second">
<h6>Developeři</h6>
<p>Produck Owner: korbel05(Jenýk Korbel)</p>
<p>Scrum master: blazej04(Michal Blažejovský)</p>
<p>Member: servit01(Petr Servít)</p>
</div>

<div class="footer_second">
<h6>Developeři</h6>
<p>Member: straka07(Jan Straka)</p>
<p>Member: prihod12(Tadeáš Příhoda)</p>
<p>Member: kovali01(Jan Kovalík)</p>
</div>

<div class="footer_second">
<h6></h6>
</div>

</div>
</div>
<div class="footer_lupinci">2020/2021 : tým Lupínci</div>
<div class="footer_odkaz">Odkaz na  <a><b>VSPJ</b></a></div>




</footer>
   
 
</body>
</html>
