 
 <HTML>
 <HEAD>
 <link href="bootstrap/css/bootstrap.css" media="all" type="text/css" rel="stylesheet">
  <link href="styly.css" media="all" type="text/css" rel="stylesheet">
 </HEAD>
 <BODY>
 </BODY>
 <div class="hlava"  ><p style="font-size: 64px">Logos Polytechnikos</p></div>
 &nbsp;<br>
&nbsp;<br>
&nbsp;<br>
 <center><img src="form.png" /></center>
 
                                                                                                               <br>
&nbsp;<br>
&nbsp;<br>
&nbsp;<br>
&nbsp;<br>
&nbsp;<br>
&nbsp;<br>
&nbsp;<br>
&nbsp;<br>




 
 
 <div class="pata" >Kok<br/><br/><br/></div>
 </HTML>

<?php

?>