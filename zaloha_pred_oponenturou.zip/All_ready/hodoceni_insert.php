 <?php
 session_start();
  
$val = $_GET['haha'];   
 require("connect.php");

   $sql = "INSERT INTO hodnoceni (kontrol,Autor,Obsah,Hodoceni,Hodnoceni1,Hodnoceni2,Hodnoceni3,Hodnoceni4,Poznamka) 
values('$val','$_SESSION[pokus]','$_SESSION[pokus2]','$_GET[celkove]','$_GET[hodnoceni1]','$_GET[hodnoceni2]','$_GET[hodnoceni3]','$_GET[hodnoceni4]','$_GET[poznamky]')";




/*$sql = "INSERT INTO kontakt (Autor,Pro,Text)
values('$_SESSION[Username]','$_GET[Pro]','$_GET[Text]')";
    */
    /*
$sql = "INSERT INTO kontakt (Nadpis,Autor,Pro,Datum,Text)
values('','$_SESSION[Username]','$_GET[Pro]','','$_GET[Text]')";
         */
         
if (mysqli_query($spojeni, $sql)) {
    echo "Záznam byl úspešně přidán";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($spojeni);
}          
mysqli_close($spojeni); 
echo $val; 
header("Location: hodnoceni_tabulka.php");exit;





 ?>