<?php
require("db_connect.php");

  if($_SESSION["Opravneni"] < 6){
 
header('Location: Index.php');
}

if($_GET['tb']=="komentar"||$_GET['tb']=="tema"||$_GET['tb']=="novinky"||$_GET['tb']=="Rezervace"||$_GET['tb']=="hodnoceni") {
    
    $statement = "DELETE FROM ".$_GET['tb']." WHERE ".$_GET['idcol']." = ".$_GET['id']." ;";
            $pdo->query($statement);
}




header('Location: admin2.php?tb='.$_GET[tb]);
 die;
?>