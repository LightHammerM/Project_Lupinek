<!DOCTYPE HTML>
<html>
  <head>
  <meta http-equiv="content-type" content="text/html; charset=utf-8">
  <meta name="generator" content="PSPad editor, www.pspad.com">
  <title>Novinky vytvoření</title>
  </head>
  <body>
    <?php
     require ("nacteni.php");
    ?>   
       
          
  </body>
</html>
