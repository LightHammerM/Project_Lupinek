<?php
session_start();

 require("connect.php");

$sql = "INSERT INTO Rezervace (Autor,Pracoviste,Clanek,Obsah,USER)
values('$_GET[Name_clan]','$_GET[Prac_clan]','$_GET[Clan_clan]','$_GET[Obsah_clan]','$_SESSION[Username]')";


if (mysqli_query($spojeni, $sql)) {
    echo "Z�znam byl �spe�n� p�id�n";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($spojeni);
}
mysqli_close($spojeni); 
header("Location: Index.php");exit;
    ?>